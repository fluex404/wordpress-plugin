<?php

$block_slug = 'uagb/image-gallery-pro';

$block_data = array(
	'dynamic_assets' => array(
		'dir'        => 'image-gallery-pro',
		'plugin-dir' => SPECTRA_PRO_DIR . '/',
	),
);
